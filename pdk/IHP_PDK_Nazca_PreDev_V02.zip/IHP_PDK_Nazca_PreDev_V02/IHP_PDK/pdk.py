import nazca as nd
from nazca.interconnects import Interconnect
import pkg_resources as pkg
from numpy import pi
import numpy as np
import json

from nazca import cfg
from .pdk_layers import *
from .pdk_constants import *
from .pdk_BB_components import *


GDS_PATH = pkg.resource_filename('IHP_PDK', 'GDS_Files/')

#==============================================================================
# Define Interconnects (settings default to values in the xsection attributes).
#==============================================================================

IC_GRB = Interconnect(xs='GRB') #Graphene bottom layer
IC_GRT = Interconnect(xs='GRT') #Graphene top layer
IC_GPS = Interconnect(xs='GPS') #Graphene GraphPas layer
IC_GRG = Interconnect(xs='GRG') #Graphene top layer
IC_GCT = Interconnect(xs='GCT') #Graphene connection holes
IC_GM1 = Interconnect(xs='GM1', radius=gm1_radius) #Metal connections for top
IC_GML = Interconnect(xs='GML', radius=gmL_radius) #Metal connection for bottom
IC_GPD = Interconnect(xs='GPD') #Graphene bottom layer

IC_SiNBWG = Interconnect(width=sinwg_width, radius=sinwg_bend_radius, xs=snw_xs) # SiN Burried waveguides
IC_SiBWG = Interconnect(width=siwg_width, radius=siwg_bend_radius, xs=swg_xs) # Si Burried waveguides

IC_SiN_NoFill = Interconnect(layer='SiNWGNoFill')
IC_SiN_Fill =Interconnect(layer='SiNWGFill')
IC_Si_NoFill = Interconnect(layer='SiWGNoFill')
IC_Si_Fill =Interconnect(layer='SiWGFill')

IC_GNC = Interconnect(xs='GNC') #Graphene bottom layer
IC_GSC = Interconnect(xs='GSC') #Graphene top layer


def export_component(component: nd.Cell, file_destination: str, file_name: str = None) -> dict :
 
    C = component.put()
    pins = {}
    print('')
    print('>>>>>>')
    print(f"exporting {C.name}...")
    if not file_name:
        file_name = C.name
    for name, pin in C.pin.items():
        print(f'{name} : {pin.xya()}')
        pins[name] = pin.xya()

    nd.export_gds(filename=f"{file_destination}/{file_name}.gds")

    with open(f"{file_destination}/{file_name}.json", "w") as outfile:
        json.dump(pins, outfile)
    print(f"...Wrote file '{file_destination}/{file_name}.json'")
    return pins

if __name__ == '__main__':
    pass