import nazca as nd
import nazca.geometries as geom
from nazca.interconnects import Interconnect
import pkg_resources as pkg
from numpy import pi
import numpy as np
import json

from nazca import cfg
from .pdk_layers import *
from .pdk_constants import *
#import IHP_PDK.pdk as ihp

#from .pdk_layers import *
#from .pdk_constants import *
GDS_PATH = pkg.resource_filename('IHP_PDK', 'GDS_Files/')


#==============================================================================
# Define Interconnects (settings default to values in the xsection attributes).
#==============================================================================
IC_GRB = Interconnect(xs='GRB') #Graphene bottom layer
IC_GRT = Interconnect(xs='GRT') #Graphene top layer
#IC_GPS = Interconnect(xs='GPS') #Graphene GraphPas layer
IC_GRG = Interconnect(xs='GRG') #Graphene GFET Gat layer
IC_GCT = Interconnect(xs='GCT') #Graphene connection holes
IC_GM1 = Interconnect(xs='GM1', radius=gm1_radius) #Metal connections for top
IC_GML = Interconnect(xs='GML', radius=gmL_radius) #Metal connection for bottom
IC_GPS = Interconnect(xs='GPS') #Graphene connection holes
IC_GPD = Interconnect(xs='GPD') #Graphene connection holes
IC_GNC = Interconnect(xs='GNC') #Graphene bottom layer
IC_GSC = Interconnect(xs='GSC') #Graphene top layer

IC_SiNBWG = Interconnect(width=sinwg_width, radius=sinwg_bend_radius, xs=snw_xs) # SiN Burried waveguides
IC_SiBWG = Interconnect(width=siwg_width, radius=siwg_bend_radius, xs=swg_xs) # Si Burried waveguides

IC_SiNBWGNoFill = Interconnect(width=sinwg_width, radius=sinwg_bend_radius, xs=snwnofill_xs) # SiN Burried waveguides nofiller area
IC_SiBWGNoFill = Interconnect(width=siwg_width, radius=siwg_bend_radius, xs=swgnofill_xs) # Si Burried waveguides nofiller area
IC_GM1NoFill = Interconnect(radius=gm1_radius, xs=gm1nofill_xs) # graphmetal1 nofiller area


#IC_SNWNoFill = Interconnect(layer='SiNWGNoFill')
#IC_SNWFill =Interconnect(layer='SiNWGFill')
#IC_SWGNoFill = Interconnect(layer='SiWGNoFill')
#IC_SWGFill =Interconnect(layer='SiWGFill')

##################################################################################
#
##################################################################################

ic = IC_SiNBWG
ic_nf = IC_GM1NoFill 
ic_grb = IC_GRB
ic_grt = IC_GRT
ic_gps = IC_GPS
ic_gm1 = IC_GM1
ic_gct = IC_GCT
ic_gml = IC_GML
ic_gpd = IC_GPD

#==============================================================================
#
# ############   BUILDING BLOCKS   ##################
#
#==============================================================================
BBfunctioncalls = []  # Store PDK BB calls for test and documentation purposes

version = {
    'cellname': 'auto',  # 'auto' will replace 'auto' with the actual cellname
    'version': '0.5',  # version string
    'owner': 'ihp-microelectronics.org',  # building block owner
}

#==============================================================================
# X. PAD_Rectangle_Standard: Standard
#==============================================================================
BBfunctioncalls.append('PAD_Rec()')

def PAD_Rec(pad_length=80, pad_width=80):

    gpd_length = pad_length - 10
    gpd_width = pad_width - 10

    with nd.Cell(name='PAD_Rec') as PAD_Rec:

        ic_gm1pad = ic_gm1.strt(length=pad_length, width=pad_width, arrow=True).put(0,0,0)
        #ic_gm1pad1 = ic_gm1.strt(length=pad_length, width=pad_width, arrow=True).put(pad_length/2,-pad_width/2,90))
        #ic_gmlpad = ic_gml.strt(length=pad_length, width=pad_width, arrow=True).put(0)
        gpd = ic_gpd.strt(length=gpd_length, width=gpd_width, arrow=False).put(5,0,0)
        

        nd.Pin('a0').put(ic_gm1pad.pin['a0'])
        nd.Pin('b0').put(ic_gm1pad.pin['b0'])
        #nd.Pin('a1').put(ic_gm1pad1.pin['a0'])
        #nd.Pin('b1').put(ic_gm1pad1.pin['b0'])
        nd.Pin('a1').put(pad_length/2, pad_length/2, 90)
        nd.Pin('b1').put(pad_length/2, -pad_length/2, 270)


        nd.put_stub()

    return PAD_Rec

BBfunctioncalls.append('PAD_Rec()')


#==============================================================================
# X. PAD_Rectangle_Standard: with GML Metal
#==============================================================================
BBfunctioncalls.append('PAD_Rec_Dual()')

def PAD_Rec_Dual(pad_length=80, pad_width=80):

    gpd_length = pad_length - 10
    gpd_width = pad_width - 10

    with nd.Cell(name='PAD_Rec_Dual') as PAD_Rec_dual:

        ic_gm1pad = ic_gm1.strt(length=pad_length, width=pad_width, arrow=True).put(0,0,0)
        ic_gmLpad = ic_gml.strt(length=pad_length, width=pad_width, arrow=True).put(0,0,0)

        gpd = ic_gpd.strt(length=gpd_length, width=gpd_width, arrow=False).put(5,0,0)
        

        nd.Pin('a0').put(ic_gm1pad.pin['a0'])
        nd.Pin('b0').put(ic_gm1pad.pin['b0'])

        nd.Pin('a1').put(pad_length/2, pad_length/2, 90)
        nd.Pin('b1').put(pad_length/2, -pad_length/2, 270)
        nd.put_stub()

    return PAD_Rec_dual

BBfunctioncalls.append('PAD_Rec_Dual()')


#==============================================================================
# X. PAD_circle_Standard: Standard
#==============================================================================
BBfunctioncalls.append('PAD_Cir()')

def PAD_Cir(pad_radius=80):

    if pad_radius <= 40:
    	gpd_radius = pad_radius - 5
    else:
    	gpd_radius = pad_radius - 10

    with nd.Cell(name='PAD_Cir') as PAD_Cir:

        ic_gm1pad_cir = nd.Polygon(points=geom.circle(radius=pad_radius, N=360), layer='GraphMetal1').put(0,0,0)
        #ic_gmlpad_cir = nd.Polygon(points=geom.circle(radius=pad_radius, N=360), layer='GraphMet1L').put(0,0,0)
        ic_gm1pad1_cir = nd.Polygon(points=geom.circle(radius=gpd_radius, N=360), layer='GraphPAD').put(0,0,0)
        

        nd.Pin('a0').put(-pad_radius,0,180)
        nd.Pin('b0').put(pad_radius,0,0)
        nd.Pin('a1').put(0,pad_radius,90)
        nd.Pin('b1').put(0,-pad_radius, 270)

        nd.put_stub()

    return PAD_Cir

BBfunctioncalls.append('PAD_Rec()')


#==============================================================================
# X. Rectangular Contact: Standard
#==============================================================================
BBfunctioncalls.append('Rec_Cont()')
def rectangular_contact(x_dim=10, y_dim=5, cont_size = 0.36,  cont_space=0.36, spacing=0.3):
    coordinates = []
    x_start = spacing
    y_start = spacing
    
    while y_start < y_dim - cont_size - cont_space :
        x = x_start
        while x < x_dim - cont_size - cont_space :
            coordinates.append((x, y_start))
            x += cont_space + cont_size 
        y_start += cont_space + cont_size 
    return coordinates


BBfunctioncalls.append('Rec_Cont()')

#==============================================================================
# X. Rectangular Contact_Array: Standard
#==============================================================================
BBfunctioncalls.append('Cont_Array()')

def Cont_Array(cont_size = 0.36, cont_space= 0.5, length=10, width=5, mgct= 0.36, type='squares', stub=False):
    with nd.Cell(name='cont_array') as cont_array:
        cont_size = cont_size
        cont_space = cont_space
        length = length
        width = width
        mgct = mgct
        match type:
            case 'squares':
                #pattern with squares according to DRC manual v1.0
                size = cont_size
                coordinates = rectangular_contact(x_dim=length, y_dim=width, cont_size = cont_size, cont_space=cont_space, spacing=mgct)
                pillar = nd.Polygon(points=geom.box(size,size), layer='GraphCont')
                x_off = 0
                y_off = size/2
            case 'pillars':
                #pattern with pillars according to Mindaugas
                size=cont_size
                coordinates = rectangular_contact(x_dim=length, y_dim=width, cont_size= cont_size, cont_space=cont_space, spacing=mgct)
                pillar = nd.Polygon(points=geom.circle(radius=size/2,N=16), layer='GraphCont')
                x_off = size/2
                y_off = size/2
            case 'patch':
                nd.Polygon(points=geom.box(length,width), layer='GraphCont').put(0,width/2)
            case _:
                raise ValueError('Contact_G type of pattern not allowed')
        if type !='patch':
            for coord in coordinates:
                pillar.put(coord[0]+x_off,coord[1]+y_off)
        
        #Pins to behave like a strt
        nd.Pin(name='a0').put(0,width/2,180)
        nd.Pin(name='b0').put(length,width/2)
        nd.Pin(name='a1').put(length/2,0,-90)
        nd.Pin(name='b1').put(length/2,width,90)
        nd.put_stub(pinshow=stub)
        return cont_array

BBfunctioncalls.append('Cont_Array()')

#==============================================================================
### SiN_Grating Coupler: Standard
#==============================================================================
@nd.bb_util.hashme('GratingCoupler')

def GratingCoupler(period=1.2, tw= 1.0, ff=0.5, N=30, tp_width=10, tp_length = 300 ,stub=False):

    with nd.Cell(name='GC_SiN') as GC_SiN:
    	gcw = tp_width
    	cl = 10 # cap length    
    	tl = (tp_length - 2*cl - period*N) #taper length
    	mb= 3.5

    	taper = ic.taper(width2=tw, width1=gcw, length=tl, arrow=False).put(2*cl + period*N,0,0)
    
    	cap1 = ic.strt(width=gcw, length=cl, arrow=False).put(taper.pin['a0'])
    
    	teeth = ic.strt(width=gcw, length=period*N, arrow=False).put()
    
    	cap2 = ic.strt(width=gcw, length=cl, arrow=False).put()
    	#cap2_nf = ic_nf.strt(width=gcw+mb, length=cl, arrow=False).put(teeth_nf, 0, 0)
    
    	gap = nd.strt(width=gcw+1, length=period*(1-ff), layer='SiNGrating')

    	# print(f"tl + cl = {tl+cl}")
    	for i in range(N):
        	gap.put(cap1.pin['b0'].move(i*period,0))

    	#nd.Pin('a0').put(taper.['b0'])
    	nd.Pin('a0').put(tp_length ,0, 0)
    	#nd.Pin('b0').put(0,0,180)
    	nd.put_stub()

    return GC_SiN

    return GC_SiN

BBfunctioncalls.append('GratingCoupler()')

#==============================================================================
### EAM: Standard
#==============================================================================
BBfunctioncalls.append('EAM()')

def EAM(gr_length=40, gr_width=5):
    with nd.Cell(name='eam_sin') as eam_sin:
        wg_length = gr_length + 10
        wg_width = 1.2
        mwg = 3
        overlap = 0.1
        nfb = 2
        tp_lg = 6

        wg_str = ic.strt(length=wg_length, width=wg_width, arrow=True).put()
        #wg_str_nf = ic_nf.strt(length=wg_length, width=wg_width + 2*mwg + nfb, arrow=True).put(0)
        
        grt_str = ic_grt.strt(length=gr_length, width=gr_width, arrow=False).put(wg_length/2 - gr_length/2, -wg_width/2 + gr_width/2)
        gm1_str_up = ic_gm1.strt(length=gr_length, width=gr_width, arrow=False).put(wg_length/2 - gr_length/2, -wg_width/2 + gr_width/2 + mwg)

        #taper_up = ic_gm1.taper(width1=gr_length, width2=80, length=tp_lg, arrow=False).put(wg_length/2, gr_width + mwg-wg_width/2,90)
 
        
        grb_str = ic_grb.strt(length=gr_length, width=gr_width, arrow=False).put(wg_length/2 - gr_length/2, wg_width/2 - gr_width/2)        
        gm1_str_do = ic_gm1.strt(length=gr_length, width=gr_width, arrow=False).put(wg_length/2 - gr_length/2, wg_width/2 - gr_width/2-mwg)
        gps_str = ic_gps.strt(length=gr_length + overlap, width=gr_width + overlap/2, arrow=False).put(wg_length/2 - gr_length/2 - overlap/2, wg_width/2 - gr_width/2 - overlap/4)        

        #taper_dw = ic_gm1.taper(width1=gr_length, width2=80, length=tp_lg, arrow=False).put(wg_length/2, -(gr_width + mwg-wg_width/2),270)

        
        nd.Pin('a0').put(wg_str.pin['a0'])
        nd.Pin('b0').put(wg_str.pin['b0'])
        nd.Pin('a1').put(wg_length/2, gr_width/2, 270)
        nd.Pin('b1').put(wg_length/2, gr_width + mwg-wg_width/2, 90)
        nd.Pin('a2').put(wg_length/2, - gr_width/2, 90)
        nd.Pin('b2').put(wg_length/2, -(gr_width + mwg-wg_width/2), 270)
        #nd.Pin('c1').put(wg_length/2, tp_lg+gr_width + mwg-wg_width/2, 90)
        #nd.Pin('c2').put(wg_length/2, -(tp_lg+gr_width + mwg-wg_width/2), 270)      
        
        nd.put_stub()
        
    return eam_sin

BBfunctioncalls.append('EAM()')


#==============================================================================
### Ring Resonator: Standard (complete with via contact)
#==============================================================================
BBfunctioncalls.append('RingMod_SiN()')

def RingMod( radius=80, gap=0.5, via_size=0.5, via_gap=0.4, layer_spacing=0.8, graphene_length = 120, wg_width =1):
    with nd.Cell(name='ringmodulator') as ringmod:
        
        wg_width =wg_width
        
        #angle of the graphene
        
        
        graphene_theta = (180/np.pi)*(graphene_length/radius)
        if graphene_theta > 80 :
            theta = 40
            theta1 = graphene_theta -theta
        else:
            theta = graphene_theta/2
            theta1 = graphene_theta/2
            

        #graphene length along the x axis
        
        # Straight waveguide (bus)
        bus_bottom = ic.strt(length=2*radius, width=wg_width).put(0, 0)
        nd.Pin('a0').put(bus_bottom.pin['a0'])
        nd.Pin('b0').put(bus_bottom.pin['b0'])
        
        # Ring resonator below bus waveguide
        ring = ic.bend(radius=radius, angle=360, width=wg_width).put(bus_bottom.pin['b0'].move(-radius, wg_width +gap))
                
        # Add pins for graphene top
        pin_gt1 = nd.Pin('a1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, -90))  # middle position
        pin_gt2 = nd.Pin('b1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, 90))  # middle position
     
        # Add pins for graphene bottom
        pin_gb1 = nd.Pin('a2').put(ring.pin['a0'].move(-radius-(wg_width)*5, -radius, -90))  # middle position
        pin_gb2 = nd.Pin('b2').put(ring.pin['a0'].move(-radius-(wg_width)*5, -radius, 90))  # middle position

        # Graphene top
        top_graphene_width = wg_width*11
        graphene_bend_top1 = ic_grb.bend(radius=radius-5*wg_width, angle=theta1, width=top_graphene_width).put(pin_gt1)
        graphene_bend_top2 = ic_grb.bend(radius=radius-5*wg_width, angle=-theta, width=top_graphene_width).put(pin_gt2)
        
        # For top graphene channel
        channel_width = 20
        graphene_bend_channel1 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=theta1, width=channel_width+20).put(pin_gt1.move(0, channel_width /2+8))
        graphene_bend_channel2 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=-theta, width=channel_width+20).put(pin_gt2.move(0, -channel_width/2-8))



        
        # Graphene bottom
        bot_graphene_width = wg_width*11
        graphene_bend_bot1 = ic_grt.bend(radius=radius+5*wg_width, angle=theta1, width=bot_graphene_width).put(pin_gb1)
        graphene_bend_bot2 = ic_grt.bend(radius=radius+5*wg_width, angle=-theta, width=bot_graphene_width).put(pin_gb2)
        
        # Graph pass
        graph_pass_width = bot_graphene_width+0.1
        graph_pass_theta1 = theta1+(0.05/(radius+5*wg_width))*57.3
        graph_pass_theta = theta+(0.05/(radius+5*wg_width))*57.3
        graphene_bend_bot1 = ic_gps.bend(radius=radius+5*wg_width, angle=graph_pass_theta1, width=graph_pass_width).put(pin_gb1)
        graphene_bend_bot2 = ic_gps.bend(radius=radius+5*wg_width, angle=-graph_pass_theta, width=graph_pass_width).put(pin_gb2)
         
        
        
        # Graphene bottom channel
        graphene_bend_channel_bot1 = ic_gm1.bend(radius=radius+2.1*top_graphene_width, angle=theta1, width=channel_width+20).put(pin_gb1.move(0, -channel_width /2-8))
        graphene_bend_channel_bot2 = ic_gm1.bend(radius=radius+2.1*top_graphene_width, angle=-theta, width=channel_width+20).put(pin_gb2.move(0, channel_width /2+8))
        

 
        # ##################################Graphene bottom channel gml######################################################
        graphene_bend_channel_bot1 = ic_gml.bend(radius=radius+2.1*top_graphene_width, angle=theta1, width=channel_width+20).put(pin_gb1.move(0, -channel_width /2-8))
        graphene_bend_channel_bot2 = ic_gml.bend(radius=radius+2.1*top_graphene_width, angle=-theta, width=channel_width+20).put(pin_gb2.move(0, channel_width /2+8))

       # ################################For top graphene channel gml###################################################
        channel_width = 20
        graphene_bend_channel1 = ic_gml.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=theta1, width=channel_width+20).put(pin_gt1.move(0, channel_width /2+8))
        graphene_bend_channel2 = ic_gml.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=-theta, width=channel_width+20).put(pin_gt2.move(0, -channel_width/2-8))
        # Add pins for graphene top metal contact
        pin_gmtop = nd.Pin('mt1').put(ring.pin['a0'].move(0, -radius, -90))  # middle position
        

        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=109, points=geom.circle(radius=radius-40, N=2000))
        disc.put(pin_gmtop)
        
        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=97, points=geom.circle(radius=radius-50, N=2000))
        disc.put(pin_gmtop) 
        
        
        
        # Metal contact for bottom graphene
        side = 80
        pin_gmbot = nd.Pin('mt2').put(ring.pin['a0'].move(-radius-0.15-side-2*bot_graphene_width-15, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbot)
        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90))
        
              
               
        # graph pad for bottom graphene
        graph_pad_factor = 0.2
        side1 = side-graph_pad_factor*side
       
        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbot.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
        #####################################################################################################################################
        ####################################################################################################################################
	# Added metal strip to the Ground, other metal on the left, and the connection between the two ground added on 20 sep 2024
        pin_gmbotleft = nd.Pin('mt3').put(ring.pin['a0'].move(+radius+0.15+2*bot_graphene_width+15, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbotleft)
        side1 = side-graph_pad_factor*side
        
        
        ########for dual####
        rectangledual = nd.Polygon(layer=110, points=geom.rectangle(length=side, height=side))
        
        rectangledual.put(pin_gmbot)
        rectangledual1 = nd.Polygon(layer=110, points=geom.rectangle(length=side, height=side))
        rectangledual1.put(pin_gmbotleft)
        # Top graphene metal contact disc
        discdual = nd.Polygon(layer=110, points=geom.circle(radius=radius-40, N=2000))
        discdual.put(pin_gmtop)

        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbotleft.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side/4, height=side))
        rectangledual = nd.Polygon(layer=110, points=geom.rectangle(length=side/4, height=side))
        rectangledual.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangle.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side/4, height=side))
        rectangledual = nd.Polygon(layer=110, points=geom.rectangle(length=side/4, height=side))
        rectangle.put(pin_gmbotleft.move(-radius + 1.5*side - bot_graphene_width + 0.9, -radius + (side*graph_pad_factor)/4))
        rectangledual.put(pin_gmbotleft.move(-radius + 1.5*side - bot_graphene_width + 0.9, -radius + (side*graph_pad_factor)/4))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=2*(graph_pad_factor*side/2 + side/2 + radius) + side/4+46, height=side/4))
        rectangledual = nd.Polygon(layer=110, points=geom.rectangle(length=2*(graph_pad_factor*side/2 + side/2 + radius) + side/4+46, height=side/4))
        rectangle.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangledual.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        ###################################################################################################################################
        ###################################################################################################################################		
        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90)) 
        

        radius1 = radius-channel_width/4.5
        
        inner_radius = radius1 - 8
        outer_radius = radius1 -4.5
        
        average_radius = (inner_radius + outer_radius) / 2
        circumference_segment = 2 * np.pi * average_radius

        # Calculate the number of vias that can fit along the circumference segment
        num_vias_per_layer = int(circumference_segment / (via_size + via_gap))
    
    # Calculate the number of layers 
        radial_distance = outer_radius - inner_radius
        num_layers = int(radial_distance / layer_spacing)
        
        angle_range = theta
        angle_range1 = theta1
        num_layers = 4
        
        
        
        for layer in range(num_layers):
            adjusted_radius = radius1  - layer * layer_spacing  
          
            effective_circumference1 = 2 * np.pi * adjusted_radius * (angle_range1 / 360)  
            effective_circumference = 2 * np.pi * adjusted_radius * (angle_range / 360)  # part of circumference used
            num_vias1 = int(effective_circumference1 / (via_size + via_gap))  
            num_vias = int(effective_circumference / (via_size + via_gap))  # number of vias that can fit without overlapping
            
            for i in range(num_vias1):
                angle = angle_range1 * i / num_vias1  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                
                 
            for i in range(num_vias):
                angle = -angle_range * i / num_vias  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                #starts from layer below 
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                 
            ########################################################################################################    
        
        radius2 = radius+channel_width/5
        
        inner_radius = radius2 - 8
        outer_radius = radius2 - 5
        
        average_radius = (inner_radius + outer_radius) / 2
        circumference_segment2 = 2 * np.pi * average_radius

        
        num_vias_per_layer2 = int(circumference_segment2 / (via_size + via_gap))
    
    
        radial_distance2 = outer_radius - inner_radius
        num_layers = int(radial_distance2 / layer_spacing)
        
        angle_range = theta
        num_layers = 4
        
        
        
        for layer in range(num_layers):
            adjusted_radius = radius2  + layer * layer_spacing 
            # Recalculate the number of vias based on the adjusted radius, via size, and angle range
            effective_circumference1 = 2 * np.pi * adjusted_radius * (angle_range1 / 360)  
            effective_circumference = 2 * np.pi * adjusted_radius * (angle_range / 360)  
            num_vias1 = int(effective_circumference1 / (via_size + via_gap))  
            num_vias = int(effective_circumference / (via_size + via_gap))  
            for i in range(num_vias1):
                angle = angle_range1 * i / num_vias1  # distribute vias evenly 
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                
                 
            for i in range(num_vias):
                angle = -angle_range * i / num_vias  # distribute vias evenly 
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                #starts from layer below 
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                   
            ########################################################################################################    
            
        
        nd.put_stub()
    return ringmod

BBfunctioncalls.append('RingMod_SiN()')

#==============================================================================
### Ring Resonator: Standard (complete with Bar contact)
#==============================================================================
BBfunctioncalls.append('RingMod_SiN_Bar()')

def RingMod_Bar(wg_width = 0.7, radius=80, gap=0.5, graphene_length = 100, contact_bar_width_factor = 0.8 ):
    with nd.Cell(name='ringresonators') as rr:

        wg_width = wg_width
        
        #angle of the graphene
        
        
        graphene_theta = (180/np.pi)*(graphene_length/radius)
        if graphene_theta > 80 :
            theta = 40
            theta1 = graphene_theta -theta
        else:
            theta = graphene_theta/2
            theta1 = graphene_theta/2
            

        #graphene length along the x axis
        
        # Straight waveguide (bus)
        bus_bottom = ic.strt(length=2*radius, width=wg_width).put(0, 0)
        nd.Pin('a0').put(bus_bottom.pin['a0'])
        nd.Pin('b0').put(bus_bottom.pin['b0'])
        
        # Ring resonator below bus waveguide
        ring = ic.bend(radius=radius, angle=360, width=wg_width).put(bus_bottom.pin['b0'].move(-radius, wg_width +gap))
                
        # Add pins for graphene top
        pin_gt1 = nd.Pin('a1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, -90))  # middle position
        pin_gt2 = nd.Pin('b1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, 90))  # middle position
     
        # Add pins for graphene bottom
        pin_gb1 = nd.Pin('a2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, -90))  # middle position
        pin_gb2 = nd.Pin('b2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, 90))  # middle position

        # Graphene top
        top_graphene_width = wg_width*11
        graphene_bend_top1 = ic_grt.bend(radius=radius-5*wg_width, angle=theta1, width=top_graphene_width).put(pin_gt1)
        graphene_bend_top2 = ic_grt.bend(radius=radius-5*wg_width, angle=-theta, width=top_graphene_width).put(pin_gt2)
        
        # For top graphene channel
        channel_width = 20
        graphene_bend_channel1 = gm1.bend(radius=radius-top_graphene_width/2-channel_width/2, angle=theta1, width=channel_width).put(pin_gt1.move(0, channel_width /2))
        graphene_bend_channel2 = gm1.bend(radius=radius-top_graphene_width/2-channel_width/2, angle=-theta, width=channel_width).put(pin_gt2.move(0, -channel_width/2))
        
        # Graphene bottom
        bot_graphene_width = wg_width*11
        graphene_bend_bot1 = ic_grb.bend(radius=radius+5*wg_width, angle=theta1, width=bot_graphene_width).put(pin_gb1)
        graphene_bend_bot2 = ic_grb.bend(radius=radius+5*wg_width, angle=-theta, width=bot_graphene_width).put(pin_gb2)
        
        # Graph pass
        graph_pass_width = bot_graphene_width+0.1
        graph_pass_theta1 = theta1+(0.05/(radius+5*wg_width))*57.3
        graph_pass_theta = theta+(0.05/(radius+5*wg_width))*57.3
        graphene_bend_bot1 = ic_gps.bend(radius=radius+5*wg_width, angle=graph_pass_theta1, width=graph_pass_width).put(pin_gb1)
        graphene_bend_bot2 = ic_gps.bend(radius=radius+5*wg_width, angle=-graph_pass_theta, width=graph_pass_width).put(pin_gb2)
         
        
        
        # Graphene bottom channel
        graphene_bend_channel_bot1 = ic_gm1.bend(radius=radius+top_graphene_width/2+channel_width/2-wg_width, angle=theta1, width=channel_width).put(pin_gb1.move(0, -channel_width /2))
        graphene_bend_channel_bot2 = ic_gm1.bend(radius=radius+top_graphene_width/2+channel_width/2-wg_width, angle=-theta, width=channel_width).put(pin_gb2.move(0, channel_width /2))
        
        # Add pins for graphene top metal contact
        pin_gmtop = nd.Pin('mt1').put(ring.pin['a0'].move(0, -radius, -90))  # middle position
        
   
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=109, points=geom.circle(radius=radius-20, N=1000))
        disc.put(pin_gmtop)
        
        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=97, points=geom.circle(radius=radius-30, N=1000))
        disc.put(pin_gmtop) 
        
 
        # Metal contact for bottom graphene
        side = 80
        pin_gmbot = nd.Pin('mt2').put(ring.pin['a0'].move(-radius-0.15-side-2*bot_graphene_width, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbot)
        
        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90))
 
        
               
        # graph pad for bottom graphene
        graph_pad_factor = 0.4
        side1 = side-graph_pad_factor*side
       
        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbot.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
        
        # top graphene bar contact 
        bar_width =  wg_width*contact_bar_width_factor
        top_graphene_bar_length1 = theta1
        top_graphene_bar_length = theta
        #from right first
        graphene_bend_top1 = ic_gct.bend(radius=radius-top_graphene_width*0.2-5*wg_width, angle=top_graphene_bar_length1, width=bar_width).put(pin_gt1.move(0, top_graphene_width*0.1))
        graphene_bend_top2 = ic_gct.bend(radius=radius-top_graphene_width*0.2-5*wg_width, angle=-top_graphene_bar_length, width=bar_width).put(pin_gt2.move(0, -top_graphene_width*0.1))
        #from right second
        graphene_bend_top1 = ic_gct.bend(radius=radius-top_graphene_width*0.4-5*wg_width, angle=top_graphene_bar_length1, width=bar_width).put(pin_gt1.move(0, top_graphene_width*0.3))
        graphene_bend_top2 = ic_gct.bend(radius=radius-top_graphene_width*0.4-5*wg_width, angle=-top_graphene_bar_length, width=bar_width).put(pin_gt2.move(0, -top_graphene_width*0.3))  

        
        # bottom graphene bar contact

        bot_graphene_bar_length1 = theta1
        bot_graphene_bar_length = theta
        #from left first
        graphene_bend_bot1 = ic_gct.bend(radius=radius+5*wg_width, angle=bot_graphene_bar_length1, width=bar_width).put(pin_gb1.move(0, -bot_graphene_width*0.1))
        graphene_bend_bot2 = ic_gct.bend(radius=radius+5*wg_width, angle=-bot_graphene_bar_length, width=bar_width).put(pin_gb2.move(0, bot_graphene_width*0.1))
         #from left second
        graphene_bend_bot1 = ic_gct.bend(radius=radius+5*wg_width+top_graphene_width*0.2, angle=bot_graphene_bar_length1, width=bar_width).put(pin_gb1.move(0, -bot_graphene_width*0.3))
        graphene_bend_bot2 = ic_gct.bend(radius=radius+5*wg_width+top_graphene_width*0.2, angle=-bot_graphene_bar_length, width=bar_width).put(pin_gb2.move(0, bot_graphene_width*0.3))  
        nd.put_stub()
      
                               
        
        nd.put_stub()
    return rr


BBfunctioncalls.append('RingMod_SiN_Bar()')

#==============================================================================
### Bend Ring Resonator: Standard (complete with via contact)
#==============================================================================
BBfunctioncalls.append('BendRingMod_SiN()')

def BendRingMod_SiN(radius=80, gap=0.2, via_size=0.5, via_gap=0.4, layer_spacing=0.8, graphene_length = 20, wg_width =1):
    with nd.Cell(name='ringresonators') as rr:

        wg_width = wg_width
        
        #angle of the graphene
        
        
        graphene_theta = (180/np.pi)*(graphene_length/radius)
        if graphene_theta > 80 :
            theta = 40
            theta1 = graphene_theta -theta
        else:
            theta = graphene_theta/2
            theta1 = graphene_theta/2
            

        #graphene length along the x axis
        
        # Straight waveguide (bus)
        bus_bottom = ic.strt(length=0, width=wg_width).put(0, 0)
        bus_bottom_left = ic.strt(length=0, width=wg_width).put(bus_bottom.pin['a0'].move(2*radius, 0))
        nd.Pin('a0').put(bus_bottom.pin['a0'])
        nd.Pin('b0').put(bus_bottom.pin['b0'])
        
        nd.Pin('slr').put(bus_bottom_left.pin['a0'])
        nd.Pin('sll').put(bus_bottom_left.pin['b0'])
        
        
        
        # Ring resonator below bus waveguide
        ring = ic.bend(radius=radius, angle=360, width=wg_width).put(bus_bottom.pin['b0'].move(-radius, wg_width +gap))
                
        # Add pins for graphene top
        pin_gt1 = nd.Pin('a1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, -90))  # middle position
        pin_gt2 = nd.Pin('b1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, 90))  # middle position
     
        # Add pins for graphene bottom
        pin_gb1 = nd.Pin('a2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, -90))  # middle position
        pin_gb2 = nd.Pin('b2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, 90))  # middle position

        # Graphene top
        top_graphene_width = wg_width*11
        graphene_bend_top1 = ic_grb.bend(radius=radius-5*wg_width, angle=theta1, width=top_graphene_width).put(pin_gt1)
        graphene_bend_top2 = ic_grb.bend(radius=radius-5*wg_width, angle=-theta, width=top_graphene_width).put(pin_gt2)
        
     # For top graphene channel
        channel_width = 20
        graphene_bend_channel1 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=theta1, width=channel_width+20).put(pin_gt1.move(0, channel_width /2+8))
        graphene_bend_channel2 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=-theta, width=channel_width+20).put(pin_gt2.move(0, -channel_width/2-8))
        # ##################################Graphene bottom channel gml######################################################
        graphene_bend_channel_bot1 = ic_gml.bend(radius=radius+2.1*top_graphene_width, angle=theta1, width=channel_width+20).put(pin_gb1.move(0, -channel_width /2-8))
        graphene_bend_channel_bot2 = ic_gml.bend(radius=radius+2.1*top_graphene_width, angle=-theta, width=channel_width+20).put(pin_gb2.move(0, channel_width /2+8))

       # ################################For top graphene channel gml###################################################
        channel_width = 20
        graphene_bend_channel1 = ic_gml.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=theta1, width=channel_width+20).put(pin_gt1.move(0, channel_width /2+8))
        graphene_bend_channel2 = ic_gml.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-8, angle=-theta, width=channel_width+20).put(pin_gt2.move(0, -channel_width/2-8))     
        # Graphene bottom
        bot_graphene_width = wg_width*11
        graphene_bend_bot1 = ic_grt.bend(radius=radius+5*wg_width, angle=theta1, width=bot_graphene_width).put(pin_gb1)
        graphene_bend_bot2 = ic_grt.bend(radius=radius+5*wg_width, angle=-theta, width=bot_graphene_width).put(pin_gb2)
        
        # Graph pass
        graph_pass_width = bot_graphene_width+0.1
        graph_pass_theta1 = theta1+(0.05/(radius+5*wg_width))*57.3
        graph_pass_theta = theta+(0.05/(radius+5*wg_width))*57.3
        graphene_bend_bot1 = ic_gps.bend(radius=radius+5*wg_width, angle=graph_pass_theta1, width=graph_pass_width).put(pin_gb1)
        graphene_bend_bot2 = ic_gps.bend(radius=radius+5*wg_width, angle=-graph_pass_theta, width=graph_pass_width).put(pin_gb2)
         
        
        
        # Graphene bottom channel
        graphene_bend_channel_bot1 = ic_gm1.bend(radius=radius+2.1*top_graphene_width, angle=theta1, width=channel_width+20).put(pin_gb1.move(0, -channel_width /2-8))
        graphene_bend_channel_bot2 = ic_gm1.bend(radius=radius+2.1*top_graphene_width, angle=-theta, width=channel_width+20).put(pin_gb2.move(0, channel_width /2+8))
        
        # Add pins for graphene top metal contact
        pin_gmtop = nd.Pin('mt1').put(ring.pin['a0'].move(0, -radius, -90))  # middle position
        

        # Top graphene metal contact disc
        disc = nd.Polygon(layer=109, points=geom.circle(radius=radius-40, N=1000))
        disc.put(pin_gmtop)
        
        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=97, points=geom.circle(radius=radius-50, N=1000))
        disc.put(pin_gmtop) 
 
        # Metal contact for bottom graphene
        side = 80
        graph_pad_factor = 0.2
        side1 = side-graph_pad_factor*side
        pin_gmbot = nd.Pin('mt2').put(ring.pin['a0'].move(-radius-0.15-side-2*bot_graphene_width-15, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbot)
       

       #####################################################################################################################################
        ####################################################################################################################################
	# Added metal strip to the Ground, other metal on the left, and the connection between the two ground added on 20 sep 2024
        pin_gmbotleft = nd.Pin('mt3').put(ring.pin['a0'].move(+radius+0.15+2*bot_graphene_width+15, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbotleft)
        side1 = side-graph_pad_factor*side
        ########for dual####
        rectangledual = nd.Polygon(layer=110, points=geom.rectangle(length=side, height=side))
        
        rectangledual.put(pin_gmbot)
        rectangledual1 = nd.Polygon(layer=110, points=geom.rectangle(length=side, height=side))
        rectangledual1.put(pin_gmbotleft)
        # Top graphene metal contact disc
        discdual = nd.Polygon(layer=110, points=geom.circle(radius=radius-40, N=2000))
        discdual.put(pin_gmtop)

        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbotleft.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side/4, height=side))
        rectangledual1 = nd.Polygon(layer=110, points=geom.rectangle(length=side/4, height=side))
        rectangledual1.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangle.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side/4, height=side))
        rectangledual2 = nd.Polygon(layer=110, points=geom.rectangle(length=side/4, height=side))
        rectangledual2.put(pin_gmbotleft.move(-radius + 1.5*side - bot_graphene_width + 0.9, -radius + (side*graph_pad_factor)/4))
        rectangle.put(pin_gmbotleft.move(-radius + 1.5*side - bot_graphene_width + 0.9, -radius + (side*graph_pad_factor)/4))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=2*(graph_pad_factor*side/2 + side/2 + radius) + side/4+46, height=side/4))
        rectangledual3 = nd.Polygon(layer=110, points=geom.rectangle(length=2*(graph_pad_factor*side/2 + side/2 + radius) + side/4+46, height=side/4))
        rectangledual3.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangle.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        ###################################################################################################################################
        ###################################################################################################################################		
        
        # graph pad for bottom graphene
        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbot.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
               

       

        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90)) 
        
               
        # Adjust via placement for multiple layers with customizable layer spacing
        
        
        radius1 = radius-channel_width/4.5
        
        inner_radius = radius1 - 8
        outer_radius = radius1 -4.5
        
        average_radius = (inner_radius + outer_radius) / 2
        circumference_segment = 2 * np.pi * average_radius

        # Calculate the number of vias that can fit along the circumference segment
        num_vias_per_layer = int(circumference_segment / (via_size + via_gap))
    
    # Calculate the number of layers that can fit within the given radial distance
        radial_distance = outer_radius - inner_radius
        num_layers = int(radial_distance / layer_spacing)
        
        angle_range = theta
        angle_range1 = theta1
        num_layers = 4
        
        
        
        for layer in range(num_layers):
            adjusted_radius = radius1  - layer * layer_spacing  # each layer is closer to the center
            # Recalculate the number of vias based on the adjusted radius, via size, and angle range
            effective_circumference1 = 2 * np.pi * adjusted_radius * (angle_range1 / 360)  # part of circumference used
            effective_circumference = 2 * np.pi * adjusted_radius * (angle_range / 360)  # part of circumference used
            num_vias1 = int(effective_circumference1 / (via_size + via_gap))  # number of vias that can fit without overlapping
            num_vias = int(effective_circumference / (via_size + via_gap))  # number of vias that can fit without overlapping
            
            for i in range(num_vias1):
                angle = angle_range1 * i / num_vias1  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                
                 
            for i in range(num_vias):
                angle = -angle_range * i / num_vias  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                #starts from layer below 
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                 
            ########################################################################################################    
        # Adjust via placement for multiple layers with customizable layer spacing
        radius2 = radius+channel_width/5
        
        inner_radius = radius2 - 8
        outer_radius = radius2 - 5
        
        average_radius = (inner_radius + outer_radius) / 2
        circumference_segment2 = 2 * np.pi * average_radius

        # Calculate the number of vias that can fit along the circumference segment
        num_vias_per_layer2 = int(circumference_segment2 / (via_size + via_gap))
    
    # Calculate the number of layers that can fit within the given radial distance
        radial_distance2 = outer_radius - inner_radius
        num_layers = int(radial_distance2 / layer_spacing)
        
        angle_range = theta
        num_layers = 4
        
        
        
        for layer in range(num_layers):
            adjusted_radius = radius2  + layer * layer_spacing  # each layer is closer to the center
            # Recalculate the number of vias based on the adjusted radius, via size, and angle range
            effective_circumference1 = 2 * np.pi * adjusted_radius * (angle_range1 / 360)  # part of circumference used
            effective_circumference = 2 * np.pi * adjusted_radius * (angle_range / 360)  # part of circumference used
            num_vias1 = int(effective_circumference1 / (via_size + via_gap))  # number of vias that can fit without overlapping
            num_vias = int(effective_circumference / (via_size + via_gap))  # number of vias that can fit without overlapping
            for i in range(num_vias1):
                angle = angle_range1 * i / num_vias1  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                
                 
            for i in range(num_vias):
                angle = -angle_range * i / num_vias  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                #starts from layer below 
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                   
            ########################################################################################################    
             # Add pins for bent bus waveguide
        bent_pinr = nd.Pin('bpr').put(pin_gmtop.move(-(radius+wg_width+gap), 0, -90))  # middle position
        bent_pinl = nd.Pin('bpl').put(pin_gmtop.move(-(radius+wg_width+gap), 0, 90))  # middle position
        
        SLR = nd.Pin('slr').put(bus_bottom_left.pin['a0'].move(0, +10, 0))
        SLL = nd.Pin('sll').put(bus_bottom_left.pin['b0'].move(0, -10, 0))
        bend_radius = 40
        azero = nd.Pin('a0').put(bus_bottom.pin['a0'].move(0, -10, 0))
        bzero = nd.Pin('b0').put(bus_bottom.pin['b0'].move(0, +10, 0))
        
        
        sbendr = ic.sbend_p2p(pin1=bent_pinr, pin2=azero, width= wg_width, radius= 1.5*radius).put()
        sbendl = ic.sbend_p2p(pin1=bent_pinl, pin2=SLR, width= wg_width, radius= 1.5*radius).put()
        
        nd.put_stub()
    return rr

BBfunctioncalls.append('BendRingMod_SiN()')

#==============================================================================
### Bend Ring Resonator: Standard (complete with Bar contact)
#==============================================================================
BBfunctioncalls.append('BendRingMod_SiN_Bar()')

def BendRingMod_SiN_Bar(wg_width = 0.7, radius=80, gap=0.5, graphene_length = 100, contact_bar_width_factor = 0.8 ):
    with nd.Cell(name='ringresonators') as rr:

        wg_width = wg_width
        
        #angle of the graphene
        
        
        graphene_theta = (180/np.pi)*(graphene_length/radius)
        if graphene_theta > 80 :
            theta = 40
            theta1 = graphene_theta -theta
        else:
            theta = graphene_theta/2
            theta1 = graphene_theta/2
            

        #graphene length along the x axis
        
        # Straight waveguide (bus)
        bus_bottom = ic.strt(length=0, width=wg_width).put(0, 0)
        bus_bottom_left = ic.strt(length=0, width=wg_width).put(bus_bottom.pin['a0'].move(2*radius, 0))
        nd.Pin('a0').put(bus_bottom.pin['a0'])
        nd.Pin('b0').put(bus_bottom.pin['b0'])
        
        nd.Pin('slr').put(bus_bottom_left.pin['a0'])
        nd.Pin('sll').put(bus_bottom_left.pin['b0'])
        # Ring resonator below bus waveguide
        ring = ic.bend(radius=radius, angle=360, width=wg_width).put(bus_bottom.pin['b0'].move(-radius, wg_width +gap))
                
        # Add pins for graphene top
        pin_gt1 = nd.Pin('a1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, -90))  # middle position
        pin_gt2 = nd.Pin('b1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, 90))  # middle position
     
        # Add pins for graphene bottom
        pin_gb1 = nd.Pin('a2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, -90))  # middle position
        pin_gb2 = nd.Pin('b2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, 90))  # middle position

        # Graphene top
        top_graphene_width = wg_width*11
        graphene_bend_top1 = ic_grt.bend(radius=radius-5*wg_width, angle=theta1, width=top_graphene_width).put(pin_gt1)
        graphene_bend_top2 = ic_grt.bend(radius=radius-5*wg_width, angle=-theta, width=top_graphene_width).put(pin_gt2)
        
        # For top graphene channel
        channel_width = 20
        graphene_bend_channel1 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2, angle=theta1, width=channel_width).put(pin_gt1.move(0, channel_width /2))
        graphene_bend_channel2 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2, angle=-theta, width=channel_width).put(pin_gt2.move(0, -channel_width/2))
        
        # Graphene bottom
        bot_graphene_width = wg_width*11
        graphene_bend_bot1 = ic_grb.bend(radius=radius+5*wg_width, angle=theta1, width=bot_graphene_width).put(pin_gb1)
        graphene_bend_bot2 = ic_grb.bend(radius=radius+5*wg_width, angle=-theta, width=bot_graphene_width).put(pin_gb2)
        
        # Graph pass
        graph_pass_width = bot_graphene_width+0.1
        graph_pass_theta1 = theta1+(0.05/(radius+5*wg_width))*57.3
        graph_pass_theta = theta+(0.05/(radius+5*wg_width))*57.3
        graphene_bend_bot1 = ic_gps.bend(radius=radius+5*wg_width, angle=graph_pass_theta1, width=graph_pass_width).put(pin_gb1)
        graphene_bend_bot2 = ic_gps.bend(radius=radius+5*wg_width, angle=-graph_pass_theta, width=graph_pass_width).put(pin_gb2)
         
        
        
        # Graphene bottom channel
        graphene_bend_channel_bot1 = ic_gm1.bend(radius=radius+top_graphene_width/2+channel_width/2-wg_width, angle=theta1, width=channel_width).put(pin_gb1.move(0, -channel_width /2))
        graphene_bend_channel_bot2 = ic_gm1.bend(radius=radius+top_graphene_width/2+channel_width/2-wg_width, angle=-theta, width=channel_width).put(pin_gb2.move(0, channel_width /2))
        
        # Add pins for graphene top metal contact
        pin_gmtop = nd.Pin('mt1').put(ring.pin['a0'].move(0, -radius, -90))  # middle position

        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=109, points=geom.circle(radius=radius-20, N=1000))
        disc.put(pin_gmtop)
        
        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=97, points=geom.circle(radius=radius-30, N=1000))
        disc.put(pin_gmtop) 

        # Metal contact for bottom graphene
        side = 80
        pin_gmbot = nd.Pin('mt2').put(ring.pin['a0'].move(-radius-0.15-side-2*bot_graphene_width, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbot)
        
        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90))
        
      
        # graph pad for bottom graphene
        graph_pad_factor = 0.4
        side1 = side-graph_pad_factor*side
       
        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbot.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
        
        # top graphene bar contact 
        bar_width =  wg_width*contact_bar_width_factor
        top_graphene_bar_length1 = theta1
        top_graphene_bar_length = theta
        #from right first
        graphene_bend_top1 = ic_gct.bend(radius=radius-top_graphene_width*0.2-5*wg_width, angle=top_graphene_bar_length1, width=bar_width).put(pin_gt1.move(0, top_graphene_width*0.1))
        graphene_bend_top2 = ic_gct.bend(radius=radius-top_graphene_width*0.2-5*wg_width, angle=-top_graphene_bar_length, width=bar_width).put(pin_gt2.move(0, -top_graphene_width*0.1))
        #from right second
        graphene_bend_top1 = ic_gct.bend(radius=radius-top_graphene_width*0.4-5*wg_width, angle=top_graphene_bar_length1, width=bar_width).put(pin_gt1.move(0, top_graphene_width*0.3))
        graphene_bend_top2 = ic_gct.bend(radius=radius-top_graphene_width*0.4-5*wg_width, angle=-top_graphene_bar_length, width=bar_width).put(pin_gt2.move(0, -top_graphene_width*0.3))  
        
      
        # bottom graphene bar contact

        bot_graphene_bar_length1 = theta1
        bot_graphene_bar_length = theta
        #from left first
        graphene_bend_bot1 = ic_gct.bend(radius=radius+5*wg_width, angle=bot_graphene_bar_length1, width=bar_width).put(pin_gb1.move(0, -bot_graphene_width*0.1))
        graphene_bend_bot2 = ic_gct.bend(radius=radius+5*wg_width, angle=-bot_graphene_bar_length, width=bar_width).put(pin_gb2.move(0, bot_graphene_width*0.1))
         #from left second
        graphene_bend_bot1 = ic_gct.bend(radius=radius+5*wg_width+top_graphene_width*0.2, angle=bot_graphene_bar_length1, width=bar_width).put(pin_gb1.move(0, -bot_graphene_width*0.3))
        graphene_bend_bot2 = ic_gct.bend(radius=radius+5*wg_width+top_graphene_width*0.2, angle=-bot_graphene_bar_length, width=bar_width).put(pin_gb2.move(0, bot_graphene_width*0.3))  
        nd.put_stub()
      
         # Add pins for bent bus waveguide
        bent_pinr = nd.Pin('bpr').put(pin_gmtop.move(-(radius+wg_width+gap), 0, -90))  # middle position
        bent_pinl = nd.Pin('bpl').put(pin_gmtop.move(-(radius+wg_width+gap), 0, 90))  # middle position
        
        SLR = nd.Pin('slr').put(bus_bottom_left.pin['a0'].move(0, +10, 0))
        SLL = nd.Pin('sll').put(bus_bottom_left.pin['b0'].move(0, -10, 0))
        bend_radius = 40
        azero = nd.Pin('a0').put(bus_bottom.pin['a0'].move(0, -10, 0))
        bzero = nd.Pin('b0').put(bus_bottom.pin['b0'].move(0, +10, 0))
        
        
        sbendr = wg.sbend_p2p(pin1=bent_pinr, pin2=azero, width= wg_width, radius= 1.5*radius).put()
        sbendl = wg.sbend_p2p(pin1=bent_pinl, pin2=SLR, width= wg_width, radius= 1.5*radius).put()                      
        
        nd.put_stub()
    return rr


BBfunctioncalls.append('BendRingMod_SiN_Bar()')

#==============================================================================
### Racetract Ring Resonator: Standard (complete with via contact)
#==============================================================================
BBfunctioncalls.append('RTRingMod_SiN()')

def RTRingMod_SiN(radius=80, gap=0.5, via_size=0.5, via_gap=0.4, layer_spacing=0.8, graphene_length = 10, coupling_length = 10, wg_width =1):
    with nd.Cell(name='ringresonators') as rr:

        wg_width = wg_width
        
        #angle of the graphene
        
        
        graphene_theta = (180/np.pi)*(graphene_length/radius)
        if graphene_theta > 80 :
            theta = 40
            theta1 = graphene_theta -theta
        else:
            theta = graphene_theta/2
            theta1 = graphene_theta/2
            

        #graphene length along the x axis
        
        # Straight waveguide (bus)
        bus_bottom = ic.strt(length=2*radius+2*coupling_length, width=wg_width).put(0, 0)
        nd.Pin('a0').put(bus_bottom.pin['a0'])
        nd.Pin('b0').put(bus_bottom.pin['b0'])
        
        # Ring right
        ring = ic.bend(radius=radius, angle=180, width=wg_width).put(bus_bottom.pin['b0'].move(-radius, wg_width +gap))
        # Ring pin bottom
        pinringb = nd.Pin('rb').put(ring.pin['a0']) 
        
        # Ring pin top
        pinringt = nd.Pin('rt').put(ring.pin['a0'].move(0, -2*radius))
        
        
        # Ring left
        ring1 = ic.bend(radius=radius, angle=-180, width=wg_width).put(bus_bottom.pin['b0'].move(-radius-coupling_length, wg_width +gap, -180))
                
         # Straight Coupling length top
        Clt = ic.strt(length=coupling_length, width=wg_width).put( pinringb)
        
        # Straight Coupling length top
        Clb = ic.strt(length=coupling_length, width=wg_width).put(pinringt)
        
        
        # Add pins for graphene top
        pin_gt1 = nd.Pin('a1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, -90))  # middle position
        pin_gt2 = nd.Pin('b1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, 90))  # middle position
     
        # Add pins for graphene bottom
        pin_gb1 = nd.Pin('a2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, -90))  # middle position
        pin_gb2 = nd.Pin('b2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, 90))  # middle position

        # Graphene top
        top_graphene_width = wg_width*11
        graphene_bend_top1 = ic_grb.bend(radius=radius-5*wg_width, angle=theta1, width=top_graphene_width).put(pin_gt1)
        graphene_bend_top2 = ic_grb.bend(radius=radius-5*wg_width, angle=-theta, width=top_graphene_width).put(pin_gt2)
        
     # For top graphene channel
        channel_width = 20
        graphene_bend_channel1 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-10, angle=theta1, width=channel_width+20+5).put(pin_gt1.move(0, channel_width /2+8+2.5))
        graphene_bend_channel2 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-10, angle=-theta, width=channel_width+20+5).put(pin_gt2.move(0, -channel_width/2-8-2.5))
        # ##################################Graphene bottom channel gml######################################################
        graphene_bend_channel_bot1 = ic_gml.bend(radius=radius+2.1*top_graphene_width, angle=theta1, width=channel_width+20).put(pin_gb1.move(0, -channel_width /2-8))
        graphene_bend_channel_bot2 = ic_gml.bend(radius=radius+2.1*top_graphene_width, angle=-theta, width=channel_width+20).put(pin_gb2.move(0, channel_width /2+8))

        # ################################For top graphene channel gml###################################################
        channel_width = 20
        graphene_bend_channel1 = ic_gml.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-10, angle=theta1, width=channel_width+20+5).put(pin_gt1.move(0, channel_width /2+8+2.5))
        graphene_bend_channel2 = ic_gml.bend(radius=radius-top_graphene_width/2-channel_width/2+wg_width-10, angle=-theta, width=channel_width+20+5).put(pin_gt2.move(0, -channel_width/2-8-2.5))    
        # Graphene bottom
        bot_graphene_width = wg_width*11
        graphene_bend_bot1 = ic_grt.bend(radius=radius+5*wg_width, angle=theta1, width=bot_graphene_width).put(pin_gb1)
        graphene_bend_bot2 = ic_grt.bend(radius=radius+5*wg_width, angle=-theta, width=bot_graphene_width).put(pin_gb2)
        
        # Graph pass
        graph_pass_width = bot_graphene_width+0.1
        graph_pass_theta1 = theta1+(0.05/(radius+5*wg_width))*57.3
        graph_pass_theta = theta+(0.05/(radius+5*wg_width))*57.3
        graphene_bend_bot1 = ic_gps.bend(radius=radius+5*wg_width, angle=graph_pass_theta1, width=graph_pass_width).put(pin_gb1)
        graphene_bend_bot2 = ic_gps.bend(radius=radius+5*wg_width, angle=-graph_pass_theta, width=graph_pass_width).put(pin_gb2)
         
        
        
        # Graphene bottom channel
        graphene_bend_channel_bot1 = ic_gm1.bend(radius=radius+2.1*top_graphene_width, angle=theta1, width=channel_width+20).put(pin_gb1.move(0, -channel_width /2-8))
        graphene_bend_channel_bot2 = ic_gm1.bend(radius=radius+2.1*top_graphene_width, angle=-theta, width=channel_width+20).put(pin_gb2.move(0, channel_width /2+8))
        
        # Add pins for graphene top metal contact
        pin_gmtop = nd.Pin('mt1').put(ring.pin['a0'].move(coupling_length/2, -radius, -90))  # middle position

        # Top graphene metal contact disc
        disc = nd.Polygon(layer=109, points=geom.circle(radius=radius-40, N=1000))
        disc.put(pin_gmtop.move(0, 0))
        
        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=97, points=geom.circle(radius=radius-50, N=1000))
        disc.put(pin_gmtop.move(0, 0)) 

        # Metal contact for bottom graphene
        side = 80
        graph_pad_factor = 0.2
        side1 = side-graph_pad_factor*side
        pin_gmbot = nd.Pin('mt2').put(ring.pin['a0'].move(-radius-0.15-side-2*bot_graphene_width-10, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))

        rectangle.put(pin_gmbot)
        
        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90))
        
        
        
               
        # graph pad for bottom graphene
        graph_pad_factor = 0.2
        side1 = side-graph_pad_factor*side
       
        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbot.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
       #####################################################################################################################################
        ####################################################################################################################################
	# Added metal strip to the Ground, other metal on the left, and the connection between the two ground added on 20 sep 2024
        pin_gmbotleft = nd.Pin('mt3').put(ring.pin['a0'].move(+radius+0.15+2*bot_graphene_width+15, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbotleft)
        side1 = side-graph_pad_factor*side
        ########for dual####
        rectangledual = nd.Polygon(layer=110, points=geom.rectangle(length=side, height=side))
        
        rectangledual.put(pin_gmbot)
        rectangledual1 = nd.Polygon(layer=110, points=geom.rectangle(length=side, height=side))
        rectangledual1.put(pin_gmbotleft)
        # Top graphene metal contact disc
        discdual = nd.Polygon(layer=110, points=geom.circle(radius=radius-40, N=2000))
        discdual.put(pin_gmtop)

        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbotleft.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side/4, height=side))
        rectangledual1 = nd.Polygon(layer=110, points=geom.rectangle(length=side/4, height=side))
        rectangle.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangledual1.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side/4, height=side))
        rectangledual2 = nd.Polygon(layer=110, points=geom.rectangle(length=side/4, height=side))
        rectangledual2.put(pin_gmbotleft.move(-radius + 1.5*side - bot_graphene_width + 0.9, -radius + (side*graph_pad_factor)/4))
        rectangle.put(pin_gmbotleft.move(-radius + 1.5*side - bot_graphene_width + 0.9, -radius + (side*graph_pad_factor)/4))
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=2*(graph_pad_factor*side/2 + side/2 + radius) + side/4+41, height=side/4))
        rectangledual3 = nd.Polygon(layer=110, points=geom.rectangle(length=2*(graph_pad_factor*side/2 + side/2 + radius) + side/4+41, height=side/4))
        rectangle.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        rectangledual3.put(pin_gmbot.move(-radius + 1.5*side - bot_graphene_width, -radius + (side*graph_pad_factor)/4))
        ###################################################################################################################################
        ###################################################################################################################################		
          
        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90)) 
        
  
        # Adjust via placement for multiple layers with customizable layer spacing
        
        
        radius1 = radius-channel_width/4.5
        
        inner_radius = radius1 - 8
        outer_radius = radius1 -4.5
        
        average_radius = (inner_radius + outer_radius) / 2
        circumference_segment = 2 * np.pi * average_radius

        # Calculate the number of vias that can fit along the circumference segment
        num_vias_per_layer = int(circumference_segment / (via_size + via_gap))
    
    # Calculate the number of layers that can fit within the given radial distance
        radial_distance = outer_radius - inner_radius
        num_layers = int(radial_distance / layer_spacing)
        
        angle_range = theta
        angle_range1 = theta1
        num_layers = 4
        
        
        
        for layer in range(num_layers):
            adjusted_radius = radius1  - layer * layer_spacing  # each layer is closer to the center
            # Recalculate the number of vias based on the adjusted radius, via size, and angle range
            effective_circumference1 = 2 * np.pi * adjusted_radius * (angle_range1 / 360)  # part of circumference used
            effective_circumference = 2 * np.pi * adjusted_radius * (angle_range / 360)  # part of circumference used
            num_vias1 = int(effective_circumference1 / (via_size + via_gap))  # number of vias that can fit without overlapping
            num_vias = int(effective_circumference / (via_size + via_gap))  # number of vias that can fit without overlapping
            
            for i in range(num_vias1):
                angle = angle_range1 * i / num_vias1  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                
                 
            for i in range(num_vias):
                angle = -angle_range * i / num_vias  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                #starts from layer below 
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                 
            ########################################################################################################    
        # Adjust via placement for multiple layers with customizable layer spacing
        radius2 = radius+channel_width/5
        
        inner_radius = radius2 - 8
        outer_radius = radius2 - 5
        
        average_radius = (inner_radius + outer_radius) / 2
        circumference_segment2 = 2 * np.pi * average_radius

        # Calculate the number of vias that can fit along the circumference segment
        num_vias_per_layer2 = int(circumference_segment2 / (via_size + via_gap))
    
    # Calculate the number of layers that can fit within the given radial distance
        radial_distance2 = outer_radius - inner_radius
        num_layers = int(radial_distance2 / layer_spacing)
        
        angle_range = theta
        num_layers = 4
        
        
        
        for layer in range(num_layers):
            adjusted_radius = radius2  + layer * layer_spacing  # each layer is closer to the center
            # Recalculate the number of vias based on the adjusted radius, via size, and angle range
            effective_circumference1 = 2 * np.pi * adjusted_radius * (angle_range1 / 360)  # part of circumference used
            effective_circumference = 2 * np.pi * adjusted_radius * (angle_range / 360)  # part of circumference used
            num_vias1 = int(effective_circumference1 / (via_size + via_gap))  # number of vias that can fit without overlapping
            num_vias = int(effective_circumference / (via_size + via_gap))  # number of vias that can fit without overlapping
            for i in range(num_vias1):
                angle = angle_range1 * i / num_vias1  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                
                 
            for i in range(num_vias):
                angle = -angle_range * i / num_vias  # distribute vias evenly within the specified angle range
                x_via = pin_via.x +adjusted_radius * np.cos(np.deg2rad(angle)) 
                y_via = pin_via.y + adjusted_radius * np.sin(np.deg2rad(angle)) 
                
                #starts from layer below 
                via = nd.Polygon(layer=85, points=[(0, 0), (via_size, 0), (via_size, via_size), (0, via_size)])
                via.put(x_via, y_via, angle)
                   
            ########################################################################################################    
            
        
        nd.put_stub()
    return rr

BBfunctioncalls.append('RTRingMod_SiN()')


#==============================================================================
### Racetract Ring Resonator: Standard (complete with Bar contact)
#==============================================================================
BBfunctioncalls.append('RTRingMod_SiN_Bar()')

def RTRingMod_SiN_Bar(radius=80, gap=0.5, graphene_length = 100, wg_width = 0.7, contact_bar_width_factor = 0.8, coupling_length = 10 ):
    with nd.Cell(name='ringresonators') as rr:

        
        wg_width = wg_width
        
        #angle of the graphene
        
        
        graphene_theta = (180/np.pi)*(graphene_length/radius)
        if graphene_theta > 80 :
            theta = 40
            theta1 = graphene_theta -theta
        else:
            theta = graphene_theta/2
            theta1 = graphene_theta/2
            

        #graphene length along the x axis
        
        # Straight waveguide (bus)
        bus_bottom = ic.strt(length=2*radius+2*coupling_length, width=wg_width).put(0, 0)
        nd.Pin('a0').put(bus_bottom.pin['a0'])
        nd.Pin('b0').put(bus_bottom.pin['b0'])
        
        # Ring right
        ring = ic.bend(radius=radius, angle=180, width=wg_width).put(bus_bottom.pin['b0'].move(-radius, wg_width +gap))
        # Ring pin bottom
        pinringb = nd.Pin('rb').put(ring.pin['a0']) 
        
        # Ring pin top
        pinringt = nd.Pin('rt').put(ring.pin['a0'].move(0, -2*radius))
        
        
        # Ring left
        ring1 = ic.bend(radius=radius, angle=-180, width=wg_width).put(bus_bottom.pin['b0'].move(-radius-coupling_length, wg_width +gap, -180))
                
         # Straight Coupling length top
        Clt = ic.strt(length=coupling_length, width=wg_width).put( pinringb)
        
        # Straight Coupling length top
        Clb = ic.strt(length=coupling_length, width=wg_width).put(pinringt)
        
                
        # Add pins for graphene top
        pin_gt1 = nd.Pin('a1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, -90))  # middle position
        pin_gt2 = nd.Pin('b1').put(ring.pin['a0'].move(-radius+5*wg_width, -radius, 90))  # middle position
     
        # Add pins for graphene bottom
        pin_gb1 = nd.Pin('a2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, -90))  # middle position
        pin_gb2 = nd.Pin('b2').put(ring.pin['a0'].move(-radius-wg_width*5, -radius, 90))  # middle position

        # Graphene top
        top_graphene_width = wg_width*11
        graphene_bend_top1 = ic_grt.bend(radius=radius-5*wg_width, angle=theta1, width=top_graphene_width).put(pin_gt1)
        graphene_bend_top2 = ic_grt.bend(radius=radius-5*wg_width, angle=-theta, width=top_graphene_width).put(pin_gt2)
        
        # For top graphene channel
        channel_width = 20
        graphene_bend_channel1 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2, angle=theta1, width=channel_width).put(pin_gt1.move(0, channel_width /2))
        graphene_bend_channel2 = ic_gm1.bend(radius=radius-top_graphene_width/2-channel_width/2, angle=-theta, width=channel_width).put(pin_gt2.move(0, -channel_width/2))
        
        # Graphene bottom
        bot_graphene_width = wg_width*11
        graphene_bend_bot1 = ic_grb.bend(radius=radius+5*wg_width, angle=theta1, width=bot_graphene_width).put(pin_gb1)
        graphene_bend_bot2 = ic_grb.bend(radius=radius+5*wg_width, angle=-theta, width=bot_graphene_width).put(pin_gb2)
        
        # Graph pass
        graph_pass_width = bot_graphene_width+0.1
        graph_pass_theta1 = theta1+(0.05/(radius+5*wg_width))*57.3
        graph_pass_theta = theta+(0.05/(radius+5*wg_width))*57.3
        graphene_bend_bot1 = gps.bend(radius=radius+5*wg_width, angle=graph_pass_theta1, width=graph_pass_width).put(pin_gb1)
        graphene_bend_bot2 = gps.bend(radius=radius+5*wg_width, angle=-graph_pass_theta, width=graph_pass_width).put(pin_gb2)
         
               
        # Graphene bottom channel
        graphene_bend_channel_bot1 = ic_gm1.bend(radius=radius+top_graphene_width/2+channel_width/2-wg_width, angle=theta1, width=channel_width).put(pin_gb1.move(0, -channel_width /2))
        graphene_bend_channel_bot2 = ic_gm1.bend(radius=radius+top_graphene_width/2+channel_width/2-wg_width, angle=-theta, width=channel_width).put(pin_gb2.move(0, channel_width /2))
        
        # Add pins for graphene top metal contact
        pin_gmtop = nd.Pin('mt1').put(ring.pin['a0'].move(0, -radius, -90))  # middle position

        # Top graphene metal contact disc
        disc = nd.Polygon(layer=109, points=geom.circle(radius=radius-20, N=1000))
        disc.put(pin_gmtop)
        
        
        # Top graphene metal contact disc
        disc = nd.Polygon(layer=97, points=geom.circle(radius=radius-30, N=1000))
        disc.put(pin_gmtop) 

        # Metal contact for bottom graphene
        side = 80
        pin_gmbot = nd.Pin('mt2').put(ring.pin['a0'].move(-radius-0.15-side-2*bot_graphene_width, -radius-side/2))  # middle position
        rectangle = nd.Polygon(layer=109, points=geom.rectangle(length=side, height=side))
        rectangle.put(pin_gmbot)
        
        pin_via = nd.Pin('vialeft').put(ring.pin['a0'].move(0, -radius, -90))
  
               
        # graph pad for bottom graphene
        graph_pad_factor = 0.4
        side1 = side-graph_pad_factor*side
       
        rectangle = nd.Polygon(layer=97, points=geom.rectangle(length=side1, height=side1))
        rectangle.put(pin_gmbot.move(graph_pad_factor*side/2, graph_pad_factor*side/2))
        
        # top graphene bar contact 
        bar_width =  wg_width*contact_bar_width_factor
        top_graphene_bar_length1 = theta1
        top_graphene_bar_length = theta
        #from right first
        graphene_bend_top1 = ic_gct.bend(radius=radius-top_graphene_width*0.2-5*wg_width, angle=top_graphene_bar_length1, width=bar_width).put(pin_gt1.move(0, top_graphene_width*0.1))
        graphene_bend_top2 = ic_gct.bend(radius=radius-top_graphene_width*0.2-5*wg_width, angle=-top_graphene_bar_length, width=bar_width).put(pin_gt2.move(0, -top_graphene_width*0.1))
        #from right second
        graphene_bend_top1 = ic_gct.bend(radius=radius-top_graphene_width*0.4-5*wg_width, angle=top_graphene_bar_length1, width=bar_width).put(pin_gt1.move(0, top_graphene_width*0.3))
        graphene_bend_top2 = ic_gct.bend(radius=radius-top_graphene_width*0.4-5*wg_width, angle=-top_graphene_bar_length, width=bar_width).put(pin_gt2.move(0, -top_graphene_width*0.3))  
        
                
        # bottom graphene bar contact

        bot_graphene_bar_length1 = theta1
        bot_graphene_bar_length = theta
        #from left first
        graphene_bend_bot1 = ic_gct.bend(radius=radius+5*wg_width, angle=bot_graphene_bar_length1, width=bar_width).put(pin_gb1.move(0, -bot_graphene_width*0.1))
        graphene_bend_bot2 = ic_gct.bend(radius=radius+5*wg_width, angle=-bot_graphene_bar_length, width=bar_width).put(pin_gb2.move(0, bot_graphene_width*0.1))
         #from left second
        graphene_bend_bot1 = ic_gct.bend(radius=radius+5*wg_width+top_graphene_width*0.2, angle=bot_graphene_bar_length1, width=bar_width).put(pin_gb1.move(0, -bot_graphene_width*0.3))
        graphene_bend_bot2 = iC_gct.bend(radius=radius+5*wg_width+top_graphene_width*0.2, angle=-bot_graphene_bar_length, width=bar_width).put(pin_gb2.move(0, bot_graphene_width*0.3))  
        nd.put_stub()
      
     
        nd.put_stub()
    return rr

BBfunctioncalls.append('RTRingMod_SiN_Bar()')

#==============================================================================
# X. Snake: Standard
#==============================================================================
BBfunctioncalls.append('snake()')

def SnakeGC( waveguide_width=0.9, N=9,adjusted_length=11.95, L0=579, W2=0, spc=10, text=True, trace_length=None, stub=False, 
                  grating_taper_length=650, grating_period=1.144, Grating_taper_width=10,  
                  Grating_fill_factor=0.5):
    """
    Draw a square spiral with a given layer count, starting length, spacing, etc.
    
    Args:
        N  (int)  : Number of layers (x2).
        L0 (float): Starting length.
        W0 (float): Starting width; if None, defaults to L0.
        spc(int)  : Space between turns of the spiral.
        ic1       : Main interconnect for the spiral. If None, user must supply.
        ic2       : Secondary interconnect for the second part of spiral (out). If None, defaults to ic1.
        text(bool): Whether or not to place text reporting the spiral length.
        dON NOT TOUCH THE SPC play with N=5, L0=1500, W0=500 FOR length tunning
        ...
    """
    import time

    # Use an IHP waveguide if none is provided
    
        # Example usage of IHP waveguide:
        

    wg = 1.0  # waveguide width example
    R  = 100.0 # waveguide bend radius example
    W0 = (4*N-1)*(spc+waveguide_width)+adjusted_length
   # W0 = (4*N-1)*(spc+waveguide_width)+12
    id_tag = f"sqsp_{time.time()}"
    space  = spc + waveguide_width
    BreakPoint = 4*R
    ic1=ic
    ic2=None

    with nd.Cell(name='sqsp') as Cell:
        nd.trace.trace_start(id_tag)
        
        if ic2 is None:
            ic2 = ic1
        if W0 is None:
            W0 = L0
        
        # ---- Spiral "IN" part ----
        IN = ic1.strt(1, width=waveguide_width).put(0, 0)
        L = L0
        W = W0
        for _ in range(2*N):
            ic1.strt(L, width=waveguide_width).put()
            b1 = ic1.bend(angle=90, radius=R, width=waveguide_width).put()
            L -= space
            W -= space
            if (L + W <= BreakPoint) or (min([L, W]) <= 0):
                break
            
            ic1.strt(W, width=waveguide_width).put()
            b1 = ic1.bend(angle=90, radius=R, width=waveguide_width).put()
            L -= space
            W -= space
            if (L + W <= BreakPoint) or (min([L, W]) <= 0):
                break
        print(W)
        # ---- Spiral "OUT" part ----
        L = L0
        W = W0
        # Adjust OUT start to right & up for demonstration (can be changed)
        OUT = ic2.strt(1, width=waveguide_width).put(L0+spc+4, W0 + 2*R, flop=True)
        
        for _ in range(2*N):
            ic2.strt(L, width=waveguide_width).put()
            b2 = ic2.bend(angle=90, radius=R, width=waveguide_width).put()
            L -= space
            W -= space
            if (L + W <= BreakPoint) or (min([L, W]) <= 0):
                break
            
            ic2.strt(W, width=waveguide_width).put()
            b2 = ic2.bend(angle=90, radius=R, width=waveguide_width).put()
            L -= space
            W -= space
            if (L + W <= BreakPoint) or (min([L, W]) <= 0):
                break
        # Connect the final two bends
        ic1.sbend_p2p(b1, b2, radius=R, arrow = True, width=waveguide_width, Lstart=100).put()
        
#def GratingCoupler_SiN(period=1.2, ff=0.5, N=30, wg_width= 1, tp_width=10, tp_length = 300, cap_length=10):

        # Place pins
        grating = GratingCoupler_SiN(period=grating_period, tp_width=Grating_taper_width, wg_width = waveguide_width, ff=Grating_fill_factor, tp_length=grating_taper_length, N=30, cap_length=10)
        
        Grating_right = grating.put(OUT.pin['a0'])  # Place at pin 'a0'
        Grating_left = grating.put(OUT.pin['a0'].move(-(L0+grating_taper_length/2-104), 0, 180))  # Place at pin 'a0'
        
        s_bend = ic1.bend_strt_bend_p2p(
            pin1=IN.pin["a0"],
            pin2=Grating_left.pin["a0"],
            radius1=R,
            radius2=R,
            width=waveguide_width,
            ictype="shortest",
            arrow=True,
        ).put()
        nd.Pin('a0').put(IN.pin['a0'])
        nd.Pin('b0').put(OUT.pin['a0'])
         # 7) Define the spiral's global pins
        #    'a0' at the very input (IN.pin['a0'])
        nd.Pin('a0').put(IN.pin['a0'])

        #    'b0' at the end of the s-bend, i.e. s_bend.pin['b0']
        nd.Pin('b0').put(s_bend.pin['b0'])
        # Enable automatic labeling of pins
        total_length = nd.trace.trace_length(id_tag)
        
        nd.trace.trace_stop()
        

        # 7) Place text with final length
        
        if trace_length is not None:
            trace_length[0] = total_length
        if text:
            nd.text(
                layer=119,
                text=f"total_length = {round(total_length/10000,1)} cm, Wg_Width = {waveguide_width} um",
                height=30
            ).put(0, -50)

        nd.put_stub()
        
        return Cell


BBfunctioncalls.append('snake()')



####################################################################################################################################################################################

## Graphene Electrical Components 

#####################################################################################################################################################################################

#==============================================================================
# X. patterning for contact: Standard
#==============================================================================
BBfunctioncalls.append('patterning()')

def IHP_pattern(wp=0.330,x_cont=1,y_cont=1,dpx=0.2,dpy=0.2, marg=0.13, pattern='null', parity='odd'):
    
    # Definition of main parameters
    # wp= pattern width
    # x_cont = length of the contact in the x direction (Assumed parallel to the current direction
    # y_cont = length of the contact in the y direction
    # dpx = distance between patterns in the x direction
    # dpy = distance between patterns in the y direction
    # marg = minimum distance accepted from the border 
    # pattern = tipes of possible patterns: # 1) orthogonal: BAR orthogonal to the direction of the current inside the contact
                                            # 2) parallel: BAR parallel to the direction of the current inside the contact
                                            # 3) via: VIA distributed across the contact
                                            # 4) NULL:NO pattern included in the contact
    # parity = defines if the pattern number in the y direction of "parallel" and "via"contacts are 'odd' or 'even'
    
    #Starting point on the X direction (the x axis is considered parallel to the current direction).
    starting_X=dpx/2+wp/2      #In our case we don't want to change to change the paraity on this direction.
                               #the first row of vias and bar will be placed at a distince equal to half the pattern distance (dpx) plus half the pattern width (wp) 
                              
    
    #Starting point on the Y direction. In this case the initial position depends on the parity parameter:
    match parity:
        case 'odd':          #for "odd" parity the first row will be placed at the center of the pattern leaving to an odd total number of columns                      
            starting_Y=0          
                
        case 'even':             #for "even" parity the first row will be placed at a distince equal to half the pattern distance (dpx) plus half the pattern width (wp) 
            starting_Y=dpy/2+wp/2
        case _:
            raise ValueError('parity value not allowed')
    # Definition of the different pattern: 
 
    match pattern:
        case 'orthogonal':
            with nd.Cell('ORTHO') as ORTHO:
                pattern_position=starting_X       #fix the pattern position to the starting point on the x direction

                # Start the cicle need to draw the full pattern, it will draw two different BAR at position +/- pattern position distant from the center of the contact
                # The cicle will repeat untill the no bars can be fitted inside the margin of the contact 
                while (pattern_position)<(x_cont-wp)/2-marg:
                    ic_gct.strt(length=y_cont-2*marg,width=wp, arrow=False).put(x_cont/2+pattern_position,-y_cont/2+marg,90)     
                    ic_gct.strt(length=y_cont-2*marg,width=wp, arrow=False).put(x_cont/2-pattern_position,-y_cont/2+marg,90)
                    pattern_position=pattern_position+wp+dpx
                nd.Pin('a0').put(x_cont, 0, 0)    # set the position of the pin along the x axis, exactly at the border of the contact with the graphene  
            return ORTHO

        case 'parallel':
            with nd.Cell('PARA') as PARA:
                pattern_position=starting_Y       #fix the pattern position to the starting point on the y direction.

                # Start the cicle need to draw the full pattern, it will draw two different BAR at position +/- pattern position distant from the center of the contact
                # The cicle will repeat untill the no bars can be fitted inside the margin of the contact 
                while (pattern_position)<(y_cont-wp)/2-marg:
                    ic_gct.strt(length=x_cont-2*marg,width=wp, arrow=False).put(marg,pattern_position,0)
                    ic_gct.strt(length=x_cont-2*marg,width=wp, arrow=False).put(marg,-pattern_position,0)
                    pattern_position=pattern_position+wp+dpy
                nd.Pin('a0').put(+x_cont, 0, 0)    # set the position of the pin along the x axis, exactly at the border of the contact with the graphene  
                #nd.put_stub()
            return PARA

        case 'via':
            with nd.Cell('VIA') as VIA:
                pattern_positionX=starting_X
                pattern_positionY=starting_Y      #fix the pattern position to the starting point on both direction.

                # Two different cicles will allow to draw the full set of vias: the fist one will scan the contact on the x direction 
                # while the second will allow to draw the vias along the y direction at every x position  
                while (pattern_positionX)<(x_cont-wp)/2-marg:
                    while (pattern_positionY)<(y_cont-wp)/2-marg:

                        ic_gct.strt(length=wp,width=wp, arrow=False).put(x_cont/2-wp/2+pattern_positionX,pattern_positionY,0)
                        ic_gct.strt(length=wp,width=wp, arrow=False).put(x_cont/2-wp/2-pattern_positionX,pattern_positionY,0)
                        ic_gct.strt(length=wp,width=wp, arrow=False).put(x_cont/2-wp/2+pattern_positionX,-pattern_positionY,0)
                        ic_gct.strt(length=wp,width=wp, arrow=False).put(x_cont/2-wp/2-pattern_positionX,-pattern_positionY,0)
                        pattern_positionY=pattern_positionY+wp+dpy
                    pattern_positionY=starting_Y
                    pattern_positionX=pattern_positionX+wp+dpx
                nd.Pin('a0').put(x_cont, 0, 0)    # set the position of the pin along the x axis, exactly at the border of the contact with the graphene  
                #nd.put_stub()
            return VIA
        case 'null':
            with nd.Cell('NULL') as NULL:
                ic_grb.strt(length=x_cont,width=y_cont).put() #s simply put a graphene layer at the contact (it will overlap with the channel one)
                nd.Pin('a0').put(+x_cont, 0, 0)
            return NULL
        case _:
            raise ValueError('pattern not allowed')


BBfunctioncalls.append('patterning()')


#==============================================================================
# X. GFET: Standard
#==============================================================================
BBfunctioncalls.append('GFET()')

def IHP_GFET(L_cha=2,W_cha=23,overlap=3, wm=10, l_pad=80, WP=0.12, DPx=0.2,DPy=0.2, C_patt="via",pari="even"):
     
    # Definition of fixed parameters:
    # L_cha = Graphene Channel length (exluded the metal overlap in the contact)
    # W_cha = Graphene Channel width
    # overlap = overlap between metal and graphene in the contact area
    # wm = width of the metal contact
    # l_pad = dimension of the pad
    # WP = pattern width 
    # DPx = distance between patterns in the x direction
    # DPy = distance between patterns in the y direction    
    # C_patt = type of pattern used
    # pari = parity of the contact

    tot_cha=L_cha+2*overlap                    #  evaluate the total length of the graphene channel
    wm2=W_cha+1                                #  make the gate 1 um wider than the graphene channel
    metal_leng=(235-tot_cha)/2-l_pad           #  Establish the lenght of the metal arm connected tho che channel (needed to keep the strutcure 235 um large)
    metal_leng2=(235+wm)/2-l_pad               #  Establish the lenght of the metal horizontal arm connected tho che gate (needed to keep the strutcure 235 um large)
    metal_leng3=205-3/2*l_pad-wm2/2-wm/2       #  Establish the lenght of the metal vertical arm connected tho che gate (needed to keep the strutcure 205 um large)
    
    # Define graphene Channel
    with nd.Cell('GraphBot') as graphen:
        ic_grb.strt(length=tot_cha,width=W_cha).put()
        nd.Pin('c0').put(overlap,0,180)
        nd.Pin('c1').put(overlap+L_cha,0,0)
        nd.Pin('a0').put(tot_cha/2,0,180)
        #nd.put_stub()
    
    # Define Gate
    with nd.Cell('GraphGat') as gate:
        gate1=IC_GRG.strt(length=L_cha,width=wm2).put(0,0)
        
        # control on the length of the channel
        if L_cha<wm:
            gate2=IC_GRG.strt(length=wm/2,width=L_cha).put(L_cha/2,-(wm2)/2,-90)
        else:
            gate2=IC_GRG.strt(length=wm/2,width=wm).put(L_cha/2,-(wm2)/2,-90)
        
        gate3=IC_GRG.strt(length=5,width=wm).put(gate2.pin['b0'])
        nd.Pin('a0').put(L_cha/2,0,0)
        nd.Pin('c0').put(gate2.pin['b0'])
        #nd.put_stub()    
        
    with nd.Cell('Metal_1') as cont1:
        pad1=PAD_Rec_Dual(pad_length=l_pad, pad_width=l_pad).put()
        #bottom mask
        line1=ic_gm1.strt(metal_leng,wm).put(pad1.pin['a1'])
        line2=ic_gm1.strt(overlap,wm2).put(line1.pin['b0'])
        #lift-off mask
        linea=ic_gml.strt(metal_leng,wm).put(pad1.pin['a1'])
        lineb=ic_gml.strt(overlap,wm2).put(linea.pin['b0'])
        
        nd.Pin('a0').put(line2.pin['b0'])
        IHP_pattern(wp=WP,x_cont=overlap,y_cont=W_cha,dpx=DPx,dpy=DPy,marg=0.05, pattern=C_patt,parity=pari).put(line1.pin['b0'])
        #nd.put_stub()
        
    with nd.Cell('Metal_2') as cont2:
        pad1=ihp.PAD_Rec_Dual(pad_length=l_pad, pad_width=l_pad).put()
        #bottom mask
        line1=ic_gm1.strt(metal_leng2,wm).put(pad1.pin['a1'].offset((l_pad-wm)/2,0,0))
        line2=ic_gm1.strt(metal_leng3,wm).put(line1.pin['b0'].rot(90).offset(+wm/2,0,0))
        line3=ic_gm1.strt(5,wm).put(line2.pin['b0'])
        #lift-off mask
        linea=ic_gml.strt(metal_leng2,wm).put(pad1.pin['a1'].offset((l_pad-wm)/2,0,0))
        lineb=ic_gml.strt(metal_leng3,wm).put(linea.pin['b0'].rot(90).offset(+wm/2,0,0))
        linec=ic_gml.strt(5,wm).put(lineb.pin['b0'])
        nd.Pin('a0').put(line3.pin['b0'])
        nd.Pin('c0').put(pad1.pin['b1'])
        IHP_pattern(wp=WP,x_cont=5,y_cont=wm,dpx=0.34,dpy=0.34,marg=0.05, pattern='via',parity=pari).put(line2.pin['b0'])
        #nd.put_stub()
        
    with nd.Cell(name='GFET') as GFET:
        
        graph=graphen.put()
        gat=gate.put(graph.pin['a0'])
        gat_cont=cont2.put(gat.pin['c0'])
        cont1.put(graph.pin['c0'])
        cont1.put(graph.pin['c1'])


    return GFET

BBfunctioncalls.append('GFET()')


#==============================================================================
# X. Hallbar: Standard
#==============================================================================
BBfunctioncalls.append('Hallbar()')

def IHP_HALL(L_cha=20,W_cha=6,L_arm=10,W_arm=2,wm=10,wm1=4, d_arm=3, overlap_cha=6, overlap_arm=2, l_pad=80,  WP=0.16, DPx=0.1733,DPy=0.1733, C_patt="null",pari="even", gated=False):
    
    # Definition of fixed parameters:
    # L_cha = Graphene Channel length (exluded the metal overlap in the contact)
    # W_cha = Graphene Channel width
    # L_arm = Graphene Arm length (exluded the metal overlap in the contact)
    # W_arm = Graphene arm width
    # wm = width of the metal close to the pad
    # wm1 = width of the metal contact
    # d_arm = distances between the arms
    # overlap_cha = overlap between metal and graphene in the contact area of the channel
    # overlap_arm = overlap between metal and graphene in the contact area of the arms
    # l_pad = dimension of the pad
    # WP = pattern width
    # DPx = distance between patterns in the x direction
    # DPy = distance between patterns in the y direction
    # C_patt = type of pattern used
    # pari = parity of the contact
    # gated = presence of the gate in the structure (True/False)
    
    
    tot_cha=L_cha+2*overlap_cha            # total length of the channel
    tot_arm=L_arm+2*overlap_arm            # total length of the arms

    gridx=(680-l_pad)/3                    # dimension necessary for keeping the Hall structure of the same size (680 um) on the x direction
    gridy=(460-l_pad)/2                    # dimension necessary for keeping the Hall structure of the same size (460 um) on the y direction
    
    #definition of the graphene structure
    with nd.Cell('GraphBot') as graphen:
        #draw the hall pattern on the graphene
        ic_grb.strt(length=tot_cha,width=W_cha, arrow=False).put()
        ic_grb.strt(length=W_arm,width=tot_arm, arrow=False).put((tot_cha-W_arm)/2)              # drawing the central arm
        ic_grb.strt(length=W_arm,width=tot_arm, arrow=False).put((tot_cha-W_arm)/2-d_arm-W_arm)  # drawing the left arm
        if gated==False:                                                                                  # drawing the right arm, in this case the length depends if the structure is gated or not
            ic_grb.strt(length=W_arm,width=tot_arm, arrow=False).put((tot_cha-W_arm)/2+d_arm+W_arm)
        elif gated==True:
            ic_grb.strt(length=W_arm,width=tot_arm/2, arrow=False).put((tot_cha-W_arm)/2+d_arm+W_arm, tot_arm/4)
            
            
        #put the pin for the contact 
        nd.Pin('c0').put(overlap_cha,0,180)
        nd.Pin('c1').put(tot_cha/2-d_arm-W_arm,L_arm/2,90)
        nd.Pin('c2').put(tot_cha/2,L_arm/2,90)
        nd.Pin('c3').put(tot_cha/2+d_arm+W_arm,L_arm/2,90)
        nd.Pin('c4').put(tot_cha/2-d_arm-W_arm,-L_arm/2,-90)
        nd.Pin('c5').put(tot_cha/2,-L_arm/2,-90)
        nd.Pin('c6').put(tot_cha/2+d_arm+W_arm,-L_arm/2,-90)
        nd.Pin('c7').put(L_cha+overlap_cha,0,0)
        nd.Pin('a0').put(tot_cha/2,0,180)
        #nd.put_stub()

    
    with nd.Cell('Metal_1') as cont1:
        pad1=ihp.PAD_Rec_Dual(pad_length=l_pad, pad_width=l_pad).put()
        #bottom mask
        line1=ic_gm1.strt(230-l_pad+wm/2,wm, arrow=False).put(pad1.pin['a1'])
        line2=ic_gm1.strt((3/2)*gridx-L_cha/2+wm,wm, arrow=False).put(line1.pin['b0'].move(-wm/2,wm/2,-90))
        #lift-off mask
        linea=ic_gml.strt(230-l_pad+wm/2,wm, arrow=False).put(pad1.pin['a1'])
        lineb=ic_gml.strt((3/2)*gridx-L_cha/2+wm,wm, arrow=False).put(linea.pin['b0'].move(-wm/2,wm/2,-90))
        
        nd.Pin('a0').put(line2.pin['b0'])
        IHP_pattern(wp=WP,x_cont=overlap_cha,y_cont=W_cha,dpx=DPx,dpy=DPy, marg=0.05, pattern=C_patt,parity=pari).put(line2.pin['b0'].rot(180))
        #nd.put_stub()

    with nd.Cell('Metal_2') as cont2:
        pad1=ihp.PAD_Rec_Dual(pad_length=l_pad, pad_width=l_pad).put()
        #bottom mask
        line1=ic_gm1.strt(gridy-l_pad/2-(tot_arm)/2+wm/2-10,wm, arrow=False).put(pad1.pin['b1'])
        line2=ic_gm1.strt((3/2)*gridx-W_arm-d_arm+wm1/2+wm,wm, arrow=False).put(line1.pin['b0'].move(-wm/2,-wm/2,90))
        line3=ic_gm1.strt(overlap_arm+wm/2+10,wm1, arrow=False).put(line2.pin['b0'].move(-wm1/2,wm/2,-90))
        #lift-off mask
        linea=ic_gml.strt(gridy-l_pad/2-(tot_arm)/2+wm/2-10,wm, arrow=False).put(pad1.pin['b1'])
        lineb=ic_gml.strt((3/2)*gridx-W_arm-d_arm+wm1/2+wm,wm, arrow=False).put(linea.pin['b0'].move(-wm/2,-wm/2,90))
        linec=ic_gml.strt(overlap_arm+wm/2+10,wm1, arrow=False).put(lineb.pin['b0'].move(-wm1/2,wm/2,-90))
        
        nd.Pin('a0').put(line3.pin['b0'])
        
        
    with nd.Cell('Metal_3') as cont3:
        pad1=ihp.PAD_Rec_Dual(pad_length=l_pad, pad_width=l_pad).put(-l_pad/2,0)
        #bottom mask
        line1=ic_gm1.strt((gridy+wm-l_pad)/2,wm, arrow=False).put(pad1.pin['b1'])
        line2=ic_gm1.strt(gridx/2+wm,wm, arrow=False).put(line1.pin['b0'].move(-wm/2,-wm/2,90))
        line3=ic_gm1.strt(gridy/2-tot_arm/2-wm/2-10,wm, arrow=False).put(line2.pin['b0'].move(-wm/2,wm/2,-90))
        line4=ic_gm1.strt(overlap_arm+3/2*wm+10,wm1, arrow=False).put(line3.pin['b0'].move(-wm/2,0,0))
        #lift-off mask
        linea=ic_gml.strt((gridy+wm-l_pad)/2,wm, arrow=False).put(pad1.pin['b1'])
        lineb=ic_gml.strt(gridx/2+wm,wm, arrow=False).put(linea.pin['b0'].move(-wm/2,-wm/2,90))
        linec=ic_gml.strt(gridy/2-tot_arm/2-wm/2-10,wm, arrow=False).put(lineb.pin['b0'].move(-wm/2,wm/2,-90))
        lined=ic_gml.strt(overlap_arm+3/2*wm+10,wm1, arrow=False).put(linec.pin['b0'].move(-wm/2,0,0))
        
        nd.Pin('a0').put(line4.pin['b0'])
        IHP_pattern(wp=WP,x_cont=overlap_arm,y_cont=W_arm,dpx=DPx,dpy=DPy, marg=0.05, pattern=C_patt,parity=pari).put(line4.pin['b0'].rot(180))

        
    with nd.Cell('Metal_4') as cont4:
        pad1=ihp.PAD_Rec_Dual(pad_length=l_pad, pad_width=l_pad).put(-l_pad/2,0)
        #bottom mask
        line1=ic_gm1.strt(gridy+wm/2-(l_pad+tot_arm)/2-10,wm, arrow=False).put(pad1.pin['b1'])
        line2=ic_gm1.strt(gridx/2+(wm+wm1)/2-d_arm,wm, arrow=False).put(line1.pin['b0'].move(-wm/2,wm/2,-90))
        line3=ic_gm1.strt(overlap_arm+wm/2+10,wm1, arrow=False).put(line2.pin['b0'].move(-wm1/2,-wm/2,+90))
        #lift-off mask
        linea=ic_gml.strt(gridy+wm/2-(l_pad+tot_arm)/2-10,wm, arrow=False).put(pad1.pin['b1'])
        lineb=ic_gml.strt(gridx/2+(wm+wm1)/2-d_arm,wm, arrow=False).put(linea.pin['b0'].move(-wm/2,wm/2,-90))
        linec=ic_gml.strt(overlap_arm+wm/2+10,wm1, arrow=False).put(lineb.pin['b0'].move(-wm1/2,-wm/2,+90))
        
        nd.Pin('a0').put(line3.pin['b0'])
        IHP_pattern(wp=WP,x_cont=overlap_arm,y_cont=W_arm,dpx=DPx,dpy=DPy, marg=0.05, pattern=C_patt,parity=pari).put(line3.pin['b0'].rot(180))

        
    with nd.Cell('GraphGat') as gate:
        gate1=IC_GRG.strt(length=L_cha,width=W_cha+1, arrow=False).put(0,0)
        gate2=IC_GRG.strt(length=wm1,width=tot_arm/2, arrow=False).put(L_cha/2-wm1/2+d_arm+W_arm, -tot_arm/4)
        nd.Pin('a0').put(L_cha/2,0,0)
        nd.Pin('c0').put(gate2.pin['b0'])
   
        
    with nd.Cell(name='HALL BAR') as HALL:
        graph=graphen.put()
        cont1.put(graph.pin['c0'])
        cont1.put(graph.pin['c7'])
        cont2_a=cont2.put(graph.pin['c1'])
        IHP_pattern(wp=WP,x_cont=overlap_arm,y_cont=W_arm,dpx=DPx,dpy=DPy, marg=0.05, pattern=C_patt,parity=pari).put(cont2_a.pin['a0'].rot(180))
        cont2_b=cont2.put(graph.pin['c6'])
        if gated==True:
            gat=gate.put(graph.pin['a0'])
            IHP_pattern(wp=WP,x_cont=overlap_arm,y_cont=wm1,dpx=0.34,dpy=0.34, marg=0.05, pattern='via',parity=pari).put(cont2_b.pin['a0'].rot(180))
        else:
            IHP_pattern(wp=WP,x_cont=overlap_arm,y_cont=W_arm,dpx=DPx,dpy=DPy, marg=0.05, pattern=C_patt,parity=pari).put(cont2_b.pin['a0'].rot(180))    
        cont3.put(graph.pin['c2'])
        cont3.put(graph.pin['c5'])
        cont4.put(graph.pin['c3'])
        cont4.put(graph.pin['c4'])
             
    return HALL


BBfunctioncalls.append('Hallbar()')


#################################################################################
# if __name__ == '__main__':
    # #Do stuff for testing
    # FocusingGratingCoupler_SiN().put(0)
    # nd.export_gds()
