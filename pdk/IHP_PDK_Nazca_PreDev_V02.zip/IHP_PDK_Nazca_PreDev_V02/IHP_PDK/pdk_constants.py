# Default values
sinwg_width = 0.7
siwg_width = 0.450
sinwg_bend_radius = 63.5
siwg_bend_radius = 63.5
gm1_radius=10
gmL_radius=10
nofill_bounds=6


#support layers
sinwg = 'SiNWG'
sinwgfill = 'SiNWFill'
sinwgnofill= 'SiNWNoFill'
siwg = 'SiWG'
Siwgfill = 'SiWFill'
Siwgnofill = 'SiWNoFill'
graphbot = 'GraphBot'
graphtop = 'GraphTop'
graphgat = 'GraphGate'
graphcontct = 'GraphCont'
graphmetal1 = 'GraphMetal1'
graphmetal1fill = 'GraphMetal1Fill'
graphmetal1nofill = 'GraphMetal1NoFill'
graphmet1l = 'GraphMetlL'
graphmet1lfill = 'GraphMetlLFill'
graphmet1lnofill = 'GraphMetlLNoFill'
singrating = 'SiNGrating'
sigrating = 'SiGrating'
graphpas = 'GraphPas'
graphpad = 'GraphPAD'


#cross sections
snw_xs = 'SNW'
snwfill_xs = 'SNWFill'
snwnofill_xs = 'SNWNoFill'
swg_xs = 'SWG'
swgfill_xs = 'SWGFill'
swgnofill_xs = 'SWGNoFill'
grb_xs = 'GRB'
grt_xs = 'GRT'
grg_xs = 'GRG'
gct_xs = 'GCT'
gml_xs = 'GML'
gm1_xs = 'GM1'
gm1fill_xs = 'GM1Fill'
gm1nofill_xs = 'GM1NoFill'
gnc_xs = 'GNC'
gncblk_xs = 'GNCBLK'
gsc_xs = 'GSC'
gscblk_xs = 'GSCBLK'
gps_xs = 'GPS'
gpd_xs = 'GPD'





