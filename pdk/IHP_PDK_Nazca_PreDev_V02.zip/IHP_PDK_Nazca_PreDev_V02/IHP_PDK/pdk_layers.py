import os
import nazca as nd

dir_path, filename = os.path.split(os.path.abspath(__file__))

# Store the path to the demopdk directory (= path of this file).
#dir_path = os.path.dirname(__file__)

# gds based BB are to be stored (and found) in the GDS_Files subdir.
#gds_path = os.path.join(dir_path, 'GDS_Files/')



#==============================================================================
# Load IHP PDK layers from the csv tables
#==============================================================================
#Layers CSV Filles                = os.path.join(dir_path, 'example.csv')
layer_file                        = os.path.join(dir_path, 'table_layers.csv')
xsections_file                    = os.path.join(dir_path, 'table_xsections.csv')
xsections_layer_map_file          = os.path.join(dir_path, 'table_xsections_layer_map.csv')
layer_colors_file                 = os.path.join(dir_path, 'table_colors_IHP.csv')

# load the tables
nd.load_layers(layer_file)
nd.load_xsections(xsections_file)
nd.load_xsection_layer_map(xsections_layer_map_file)
nd.load_layercolors(layer_colors_file)


#nd.show_layers()
#nd.show_xsections()
#nd.show_xsection_layer_map()


