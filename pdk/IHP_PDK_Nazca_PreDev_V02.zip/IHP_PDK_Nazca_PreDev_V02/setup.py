from setuptools import setup

setup(
    name='IHP',
    version='0.0.1',
    description='IHP Graphene PDK for Nazca',
    url="https://ihp-microlectronics.com",
    author="Ashraful Islam Raju - IHP GmbH",
    author_email="raju@ihp-microelectronics.com",
    packages=['IHP_PDK'],
    package_data = {
        'IHP_PDK': ['./GDS_Files/*.gds', './*.csv']
        },
    include_package_data=True,
    install_requires=['nazca', 'pandas==1.5.3'],
    classifiers=[
        'Intended Audience :: Science/Research/Engineering'
    ]
)